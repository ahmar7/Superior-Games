


let setData = () => {
    let cardImg = document.getElementById("card-img").src;
    let cardHeading = document.getElementById("card-heading").innerHTML;
    let cardPrice = document.getElementById("card-price").innerHTML;

localStorage.setItem("cardImg", cardImg)
localStorage.setItem("cardHeading", cardHeading)
localStorage.setItem("cardPrice", cardPrice)


};
let setData1 = () => {
    let cardImg1 = document.getElementById("card-img1").src;
    let cardHeading1 = document.getElementById("card-heading1").innerHTML;
    let cardPrice1 = document.getElementById("card-price1").innerHTML;

localStorage.setItem("cardImg", cardImg1)
localStorage.setItem("cardHeading", cardHeading1)
localStorage.setItem("cardPrice", cardPrice1)


};
let setData2 = () => {

let cardImg2 = document.getElementById("card-img2").src;
let cardHeading2 = document.getElementById("card-heading2").innerHTML;
let cardPrice2 = document.getElementById("card-price2").innerHTML;

localStorage.setItem("cardImg", cardImg2)
localStorage.setItem("cardHeading", cardHeading2)
localStorage.setItem("cardPrice", cardPrice2)


};
let setData3 = () => {
    
let cardImg3 = document.getElementById("card-img3").src;
let cardHeading3 = document.getElementById("card-heading3").innerHTML;
let cardPrice3 = document.getElementById("card-price3").innerHTML;

localStorage.setItem("cardImg", cardImg3)
localStorage.setItem("cardHeading", cardHeading3)
localStorage.setItem("cardPrice", cardPrice3)


};
let setData4 = () => {
let cardImg4 = document.getElementById("card-img4").src;
let cardHeading4 = document.getElementById("card-heading4").innerHTML;
let cardPrice4 = document.getElementById("card-price4").innerHTML;

localStorage.setItem("cardImg", cardImg4)
localStorage.setItem("cardHeading", cardHeading4)
localStorage.setItem("cardPrice", cardPrice4)


};
let setData5 = () => {
let cardImg5 = document.getElementById("card-img5").src;
let cardHeading5 = document.getElementById("card-heading5").innerHTML;
let cardPrice5 = document.getElementById("card-price5").innerHTML;

localStorage.setItem("cardImg", cardImg5)
localStorage.setItem("cardHeading", cardHeading5)
localStorage.setItem("cardPrice", cardPrice5)


};
let setData6 = () => {
let cardImg6 = document.getElementById("card-img6").src;
let cardHeading6 = document.getElementById("card-heading6").innerHTML;
let cardPrice6 = document.getElementById("card-price6").innerHTML;

localStorage.setItem("cardImg", cardImg6)
localStorage.setItem("cardHeading", cardHeading6)
localStorage.setItem("cardPrice", cardPrice6)


};
let setData7 = () => {
let cardImg7 = document.getElementById("card-img7").src;
let cardHeading7 = document.getElementById("card-heading7").innerHTML;
let cardPrice7 = document.getElementById("card-price7").innerHTML;

localStorage.setItem("cardImg", cardImg7)
localStorage.setItem("cardHeading", cardHeading7)
localStorage.setItem("cardPrice", cardPrice7)


};
let setData8 = () => {
let cardImg8 = document.getElementById("card-img8").src;
let cardHeading8 = document.getElementById("card-heading8").innerHTML;
let cardPrice8 = document.getElementById("card-price8").innerHTML;

localStorage.setItem("cardImg", cardImg8)
localStorage.setItem("cardHeading", cardHeading8)
localStorage.setItem("cardPrice", cardPrice8)


};
let setData9 = () => {
let cardImg9 = document.getElementById("card-img9").src;
let cardHeading9 = document.getElementById("card-heading9").innerHTML;
let cardPrice9 = document.getElementById("card-price9").innerHTML;

localStorage.setItem("cardImg", cardImg9)
localStorage.setItem("cardHeading", cardHeading9)
localStorage.setItem("cardPrice", cardPrice9)


};
let setData10 = () => {
let cardImg10 = document.getElementById("card-img10").src;
let cardHeading10 = document.getElementById("card-heading10").innerHTML;
let cardPrice10 = document.getElementById("card-price10").innerHTML;

localStorage.setItem("cardImg", cardImg10)
localStorage.setItem("cardHeading", cardHeading10)
localStorage.setItem("cardPrice", cardPrice10)


};
let setData11 = () => {
let cardImg11 = document.getElementById("card-img11").src;
let cardHeading11 = document.getElementById("card-heading11").innerHTML;
let cardPrice11 = document.getElementById("card-price11").innerHTML;

localStorage.setItem("cardImg", cardImg11)
localStorage.setItem("cardHeading", cardHeading11)
localStorage.setItem("cardPrice", cardPrice11)


};
let setData12 = () => {
let cardImg12 = document.getElementById("card-img12").src;
let cardHeading12 = document.getElementById("card-heading12").innerHTML;
let cardPrice12 = document.getElementById("card-price12").innerHTML;

localStorage.setItem("cardImg", cardImg12)
localStorage.setItem("cardHeading", cardHeading12)
localStorage.setItem("cardPrice", cardPrice12)


};

